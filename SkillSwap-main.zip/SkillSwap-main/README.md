# SkillSwap
SkillSwap is a project used for classroom purposes. 
When it is time for the Juniors to "apply" for/to company positions in the class, SkillSwap would be used to list all your skills and upload resumes to your profile for the hiring seniors to see. 

Here is the link to the wiki:
https://github.com/David24461/SkillSwap/wiki
